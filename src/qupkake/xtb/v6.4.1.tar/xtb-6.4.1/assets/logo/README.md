# The xTB Logo

<img src="./xtb.svg" alt="Extended Tight Binding" width="340"> <img src="./xtb_alt.svg" alt="Extended Tight Binding" width="300">

Created by Sebastian Ehlert.

<a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-sa/4.0/88x31.png" /></a><br />This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/">Creative Commons Attribution-ShareAlike 4.0 International License</a>.
